//
//  AboutMeKWKApp.swift
//  AboutMeKWK
//
//  Created by Scholar on 7/13/23.
//

import SwiftUI

@main
struct AboutMeKWKApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
